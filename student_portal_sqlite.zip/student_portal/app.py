import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, g

app = Flask(__name__)
app.secret_key = "student_portal_secret"
DATABASE = "students.db"

# ── DB connection helpers ──────────────────────────────────────────────────────
def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

# ── Create table + seed data on first run ─────────────────────────────────────
def init_db():
    with app.app_context():
        db = get_db()
        db.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                name      TEXT    NOT NULL,
                school    TEXT    NOT NULL,
                age       INTEGER NOT NULL,
                address   TEXT    NOT NULL,
                studytime INTEGER NOT NULL,
                internet  TEXT    NOT NULL,
                failures  INTEGER DEFAULT 0,
                G1        INTEGER DEFAULT 0,
                G2        INTEGER DEFAULT 0,
                G3        INTEGER DEFAULT 0
            )
        """)
        # Seed 10 dummy rows only if table is empty
        count = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        if count == 0:
            seed = [
                ("Priya Sharma",  "GP", 18, "Urban", 3, "Yes", 0, 15, 16, 17),
                ("Rahul Mehta",   "MS", 17, "Urban", 2, "Yes", 0, 12, 13, 14),
                ("Sneha Patel",   "GP", 15, "Rural", 1, "No",  1,  8,  9, 10),
                ("Aditya Kumar",  "GP", 16, "Urban", 4, "Yes", 0, 18, 18, 19),
                ("Ananya Singh",  "MS", 19, "Rural", 1, "No",  2,  6,  7,  8),
                ("Vikram Nair",   "GP", 17, "Urban", 3, "Yes", 0, 14, 15, 16),
                ("Kavya Reddy",   "MS", 16, "Urban", 2, "Yes", 0, 11, 12, 13),
                ("Arjun Iyer",    "GP", 18, "Rural", 1, "No",  3,  5,  5,  6),
                ("Meera Verma",   "GP", 15, "Urban", 4, "Yes", 0, 17, 17, 18),
                ("Rohan Gupta",   "MS", 17, "Urban", 2, "Yes", 1, 10, 11, 11),
            ]
            db.executemany("""
                INSERT INTO students
                  (name,school,age,address,studytime,internet,failures,G1,G2,G3)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, seed)
            db.commit()

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def home():
    db = get_db()
    students = db.execute("SELECT * FROM students").fetchall()
    total  = len(students)
    avg_g3 = round(sum(s["G3"] for s in students) / total, 1) if total else 0
    passed = sum(1 for s in students if s["G3"] >= 10)
    return render_template("home.html", total=total, avg_g3=avg_g3, passed=passed)

@app.route("/students")
def student_list():
    db = get_db()
    students = db.execute("SELECT * FROM students ORDER BY id").fetchall()
    return render_template("students.html", students=students)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name      = request.form.get("name", "").strip()
        school    = request.form.get("school", "GP")
        age       = request.form.get("age", "")
        address   = request.form.get("address", "Urban")
        studytime = request.form.get("studytime", "2")
        internet  = request.form.get("internet", "Yes")
        G1        = request.form.get("G1", "0")
        G2        = request.form.get("G2", "0")
        G3        = request.form.get("G3", "0")

        if not name or not age:
            flash("Please fill in all required fields.", "error")
            return render_template("register.html")

        db = get_db()
        db.execute("""
            INSERT INTO students (name,school,age,address,studytime,internet,failures,G1,G2,G3)
            VALUES (?,?,?,?,?,?,0,?,?,?)
        """, (name, school, int(age), address, int(studytime), internet,
              int(G1), int(G2), int(G3)))
        db.commit()
        flash(f"Student '{name}' registered successfully!", "success")
        return redirect(url_for("student_list"))

    return render_template("register.html")

@app.route("/edit/<int:student_id>", methods=["GET", "POST"])
def edit(student_id):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        flash("Student not found.", "error")
        return redirect(url_for("student_list"))

    if request.method == "POST":
        name      = request.form.get("name", "").strip()
        school    = request.form.get("school", "GP")
        age       = request.form.get("age", "")
        address   = request.form.get("address", "Urban")
        studytime = request.form.get("studytime", "2")
        internet  = request.form.get("internet", "Yes")
        G1        = request.form.get("G1", "0")
        G2        = request.form.get("G2", "0")
        G3        = request.form.get("G3", "0")

        db.execute("""
            UPDATE students
            SET name=?, school=?, age=?, address=?, studytime=?, internet=?, G1=?, G2=?, G3=?
            WHERE id=?
        """, (name, school, int(age), address, int(studytime), internet,
              int(G1), int(G2), int(G3), student_id))
        db.commit()
        flash(f"Student '{name}' updated successfully!", "success")
        return redirect(url_for("student_list"))

    return render_template("edit.html", student=student)

@app.route("/delete/<int:student_id>", methods=["POST"])
def delete(student_id):
    db = get_db()
    student = db.execute("SELECT name FROM students WHERE id=?", (student_id,)).fetchone()
    if student:
        db.execute("DELETE FROM students WHERE id=?", (student_id,))
        db.commit()
        flash(f"Student '{student['name']}' deleted successfully!", "success")
    return redirect(url_for("student_list"))

@app.route("/about")
def about():
    return render_template("about.html")

# ── Start ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
